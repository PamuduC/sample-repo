# Loop een Array

## Instructies

Maak een programma dat elk 3de nummer tussen 1 en 20 opsomt en het afdrukt naar de console.

> TIP: gebruik een for-loop en pas de iteratie-uitdrukking aan

## Rubriek

| Criteria | Voorbeeldig                               | Voldoende                 | Moet worden verbeterd              |
| -------- | --------------------------------------- | ------------------------ | ------------------------------ |
|          | Programma loopt correct en wordt becommentarieerd | Programma wordt niet becommentarieerd | Programma is onvolledig of bevat fouten |