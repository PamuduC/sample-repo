# Maak een spel na

## Instructies

Gebruik de codevoorbeelden in de les om een weergave te maken van een spel dat u leuk vindt. Het zal een eenvoudig spel moeten zijn, maar het doel is om ofwel de class of het compositiepatroon en het pub/subpatroon te gebruiken om te laten zien hoe een spel zou kunnen starten. Wees creatief!

## Rubriek

| Criteria | Voorbeeldig                                               | Voldoende                                              | Moet worden verbeterd                                   |
| -------- | ------------------------------------------------------- | ----------------------------------------------------- | --------------------------------------------------- |
|          | Drie elementen worden op het scherm geplaatst en gemanipuleerd | Twee elementen worden op het scherm geplaatst en gemanipuleerd | Een element wordt op het scherm geplaatst en gemanipuleerd |