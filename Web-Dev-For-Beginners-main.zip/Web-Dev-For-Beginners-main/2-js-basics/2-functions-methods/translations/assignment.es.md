# Diversión con funciones

## Instrucciones

Cree diferentes funciones, tanto funciones que devuelvan algo como funciones que no devuelvan nada.

Vea si puede crear una función que tenga una combinación de parámetros y parámetros con valores predeterminados.

## Rúbrica

| Criterios | Ejemplar | Adecuado | Necesita mejorar |
| -------- | ------------------------------------ | -------------- | ----------------- |
| | La solución se ofrece con dos o más funciones de buen rendimiento con diversos parámetros | La solución de trabajo se ofrece con una función y pocos parámetros | La solución tiene errores |
