# Laçar um Array

## Instruções

Criar um programa que enumere cada 3º número entre 1-20 e imprime-o para a consola.

>  DICA: usar um for-loop e modificar a expressão de iteração

## Rubrica

| Critérios | Exemplar                               | Adequado                 | Necessidades de Melhoria              |
| -------- | --------------------------------------- | ------------------------ | ------------------------------ |
|          | Programa funciona correctamente e é comentado | Programa não é comentado | Programa incompleto ou buggy
