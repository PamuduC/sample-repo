# Pengantar JavaScript

JavaScript adalah bahasa web. Dalam empat pelajaran ini, Anda akan mempelajari dasar-dasarnya.

### Topik

1. [Variabel dan Jenis Data](../1-data-types/translations/README.id.md)
2. [Fungsi dan Metode](../2-functions-methods/translations/README.id.md)
3. [Membuat Keputusan dengan JavaScript](../3-making-decisions/translations/README.id.md)
4. [Array dan Loop](../4-arrays-loops/translations/README.id.md)

### Kredit

Pelajaran ini ditulis dengan ♥️ ️oleh [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) dan [Chris Noring](https://twitter.com/chris_noring)
