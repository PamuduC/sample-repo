# Seronok dengan Fungsi

## Arahan

Buat fungsi yang berbeza, kedua fungsi yang mengembalikan sesuatu dan fungsi yang tidak mengembalikan apa-apa.

Lihat apakah anda dapat membuat fungsi yang memiliki gabungan parameter dan parameter dengan nilai lalai.

## Rubrik

| Kriteria | Contoh                                                                             | Mencukupi                                                         | Usaha Lagi |
| -------- | -------------------------------------------------------------------------------------- | ---------------------------------------------------------------- | ----------------- |
|          | Penyelesaian ditawarkan dengan dua atau lebih fungsi yang berfungsi dengan baik dengan pelbagai parameter | Penyelesaian kerja ditawarkan dengan satu fungsi dan beberapa parameter | Penyelesaian mempunyai pepijat |