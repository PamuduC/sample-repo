# Refatore o estilo de sua extensão

## Instruções

O código base para esta extensão vem completo com estilos, mas você não precisa usá-los; faça sua própria estilização editando seu arquivo css.

## Rubrica

| Critérios | Exemplar | Adequado | Necessita de melhoria |
| -------- | -------------------------------------------- | --------------------- | ----------------- |
| | O código é enviado com novos estilos funcionais	 | O estilo está incompleto | Os estilos contém erros |