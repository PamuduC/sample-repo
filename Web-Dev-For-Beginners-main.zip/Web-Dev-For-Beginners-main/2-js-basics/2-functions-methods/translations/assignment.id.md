# Bersenang-senang dengan Fungsi

## Instruksi

Buat fungsi yang berbeda, baik fungsi yang mengembalikan sesuatu maupun fungsi yang tidak mengembalikan apa pun.

Lihat apakah Anda dapat membuat fungsi yang memiliki campuran parameter dan parameter dengan nilai default.

## Rubrik

| Kriteria | Contoh                                                                                            | Memenuhi Syarat                                                   | Perlu Perbaikan     |
|----------|---------------------------------------------------------------------------------------------------|-------------------------------------------------------------------|---------------------|
|          | Solusi ditawarkan dengan dua atau lebih fungsi yang berkinerja baik dengan parameter yang beragam | Solusi kerja ditawarkan dengan satu fungsi dan beberapa parameter | Solusi memiliki bug |
