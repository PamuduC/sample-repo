# ਵੈੱਬ ਵਿਕਾਸ ਨਾਲ ਸ਼ੁਰੂਆਤ ਕਰਨਾ

ਕੋਰਸ ਦੇ ਇਸ ਭਾਗ ਵਿੱਚ, ਤੁਹਾਨੂੰ ਇੱਕ ਪੇਸ਼ੇਵਰ ਵਿਕਾਸਕਾਰ ਬਣਨ ਲਈ ਮਹੱਤਵਪੂਰਨ ਗੈਰ-ਪ੍ਰੋਜੈਕਟ ਅਧਾਰਤ ਸੰਕਲਪਾਂ ਨਾਲ ਜਾਣੂ ਕਰਵਾਇਆ ਜਾਵੇਗਾ।

### ਵਿਸ਼ਾ

1. [ਪ੍ਰੋਗਰਾਮਿੰਗ ਭਾਸ਼ਾਵਾਂ ਅਤੇ ਵਪਾਰਕ ਸਾਧਨਾਂ ਦੀ ਜਾਣ-ਪਛਾਣ](../1-intro-to-programming-languages/translations/README.en.md)
2. [GitHub ਬੇਸਿਕਸ](../2-github-basics/translations/README.en.md)
3. [ਪਹੁੰਚਯੋਗਤਾ ਮੂਲ ਗੱਲਾਂ](../3-accessibility/translations/README.en.md)

### ਕ੍ਰੈਡਿਟ

ਪਹੁੰਚਯੋਗਤਾ ਦੀਆਂ ਬੁਨਿਆਦੀ ਗੱਲਾਂ [ਕ੍ਰਿਸਟੋਫਰ ਹੈਰੀਸਨ](https://twitter.com/geektrainer) ਦੁਆਰਾ ♥️ ਦੁਆਰਾ ਲਿਖੀਆਂ ਗਈਆਂ ਸਨ।

GitHub ਦੀ ਜਾਣ-ਪਛਾਣ [floordress](https://twitter.com/floordtrees) ਦੁਆਰਾ ♥️ ਦੁਆਰਾ ਲਿਖੀ ਗਈ ਸੀ।

ਪ੍ਰੋਗਰਾਮਿੰਗ ਭਾਸ਼ਾਵਾਂ ਅਤੇ ਵਪਾਰਕ ਸਾਧਨਾਂ ਦੀ ਜਾਣ-ਪਛਾਣ [ਜੈਸਮੀਨ ਗ੍ਰੀਨਵੇ] (https://twitter.com/paladique) ਦੁਆਰਾ ♥️ ਦੁਆਰਾ ਲਿਖੀ ਗਈ ਸੀ।