# Mock up permainan

## Arahan

Dengan menggunakan contoh kod dalam pelajaran, tulis representasi permainan yang anda nikmati. Ini mestilah permainan yang sederhana, tetapi tujuannya adalah menggunakan kelas atau corak komposisi dan corak pub / sub untuk menunjukkan bagaimana permainan dapat dilancarkan. Dapatkan kreatif!

## Rubrik

| Kriteria | 
Contoh                                               | Mencukupi                                              | Usaha Lagi                                   |
| -------- | ------------------------------------------------------- | ----------------------------------------------------- | --------------------------------------------------- |
|          | Tiga elemen diletakkan di skrin dan dimanipulasi | Dua elemen diletakkan di skrin dan dimanipulasi | Satu elemen diletakkan di skrin dan dimanipulasi |