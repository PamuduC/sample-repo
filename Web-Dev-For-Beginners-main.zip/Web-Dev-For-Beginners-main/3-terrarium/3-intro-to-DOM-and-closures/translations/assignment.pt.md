# Trabalhe um pouco mais com a DOM

## Instruções

Pesquise a DOM um pouco mais 'adotando' um elemento DOM. Visite a [lista de interfaces DOM](https://developer.mozilla.org/docs/Web/API/Document_Object_Model) do MDN e escolha uma. Encontre-o em um web site e escreva uma explicação de como ele é usado.

## Rubrica

| Criterio | Exemplar                                     | Adequado                                         | Precisa de melhoria       |
| -------- | --------------------------------------------- | ------------------------------------------------ | ----------------------- |
|          | A redação do parágrafo é apresentada com exemplo |  redação do parágrafo é apresentada sem exemplo | Nenhum texto é apresentado |
