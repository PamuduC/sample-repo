# Restyle your Extension

## Instructions

The codebase for this extension comes complete with styles, but you don't have to use them; make your extension your own by restyling it by editing its css file.

## Rubric

| Criteria | Exemplary                                    | Adequate              | Needs Improvement |
| -------- | -------------------------------------------- | --------------------- | ----------------- |
|          | Code is submitted with functional new styles | Styling is incomplete | Styles are buggy  |