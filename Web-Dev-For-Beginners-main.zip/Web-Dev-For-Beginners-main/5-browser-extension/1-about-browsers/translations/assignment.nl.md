# Restyle uw extensie

## Instructies

De codebase voor deze extensie wordt compleet geleverd met stijlen, maar u hoeft ze niet te gebruiken; maak uw extensie uw eigen door deze te restylen door het css-bestand te bewerken.

## Rubriek

| Criteria | Voorbeeldig                                    | Voldoende              | Moet worden verbeterd |
| -------- | -------------------------------------------- | --------------------- | ----------------- |
|          | Code wordt ingediend met functionele nieuwe stijlen | Styling is niet compleet | Stijlen zijn buggy  |