# JavaScript 소개하기

JavaScript는 웹의 언어입니다. 이 네 가지 강의에서 기초를 배우게됩니다.

### 주제

1. [변수와 데이터 타입](../1-data-types/translations/README.ko.md)
2. [함수와 메소드](../2-functions-methods/translations/README.ko.md)
3. [JavaScript로 결정하기](../3-making-decisions/translations/README.ko.md)
4. [배열과 반복](../4-arrays-loops/translations/README.ko.md)

### 크레딧

These lessons were written with ♥️ by [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) and [Chris Noring](https://twitter.com/chris_noring)