# Werk wat meer met de DOM

## Instructies

Onderzoek de DOM een beetje meer door een DOM-element te 'adopteren'. Bezoek de [lijst met DOM-interfaces](https://developer.mozilla.org/nl/docs/Web/API/Document_Object_Model) van MDN en kies er een. Zoek dat het wordt gebruikt op een website op internet en schrijf een uitleg over hoe het wordt gebruikt.

## Rubriek

| Criteria | Voorbeeldig                                     | Voldoende                                         | Moet worden verbeterd       |
| -------- | --------------------------------------------- | ------------------------------------------------ | ----------------------- |
|          | Er wordt een alinea-opsomming gegeven, met een voorbeeld | Paragraafopmaak wordt gepresenteerd, zonder voorbeeld | Er wordt geen beschrijving gepresenteerd |
