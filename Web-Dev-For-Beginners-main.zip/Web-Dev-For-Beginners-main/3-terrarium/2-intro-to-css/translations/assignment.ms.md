# Pemfaktoran Semula CSS

## Arahan

Nyalakan semula terarium menggunakan Flexbox atau CSS Grid, dan ambil tangkapan skrin untuk menunjukkan bahawa anda telah mengujinya di beberapa penyemak imbas. Anda mungkin perlu mengubah markup jadi buat versi aplikasi baharu dengan seni yang ada untuk anda memfaktorkan. Jangan bimbang menjadikan unsur-unsur itu boleh diseret; hanya memfaktorkan HTML dan CSS buat masa ini.

## Rubrik

| Kriteria | Contoh                                                         | Mencukupi                      | Usaha Lagi                    |
| -------- | ----------------------------------------------------------------- | ----------------------------- | ------------------------------------ |
|          | Bentangkan terarium yang diperbaiki sepenuhnya menggunakan Flexbox atau CSS Grid | Susun semula beberapa elemen | Gagal menyusun semula terarium sama sekali |