# Lavorare un po' di più con il DOM

## Istruzioni

Fare ulteriore ricerca sul DOM "adottando" un elemento DOM. Visitare l' [elenco delle interfacce DOM di](https://developer.mozilla.org/it/docs/Web/API/Document_Object_Model) MDN e sceglierne una. Trovarla in uso su un sito web, e scrivere una spiegazione di come viene utilizzata.

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | --------------------------------------------- | ------------------------------------------------ | ----------------------- |
|          | Viene presentata la redazione del paragrafo, con un esempio | Viene presentata la redazione del paragrafo, senza esempio | Non viene presentato alcun resoconto |
  